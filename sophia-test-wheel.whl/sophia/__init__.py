"""SOPHIA Python package."""

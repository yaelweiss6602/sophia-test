"""A SQLAlchemy model base that can be used across model classes."""

from sqlalchemy.orm import registry

_registry = registry()

Base = _registry.generate_base()

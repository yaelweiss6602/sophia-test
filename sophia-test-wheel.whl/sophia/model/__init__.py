"""SQL-Alchemy-based model classes for keepng system state."""

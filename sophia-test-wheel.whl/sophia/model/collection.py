"""Implementation of core collection sub-model."""
import datetime
import uuid
from typing import Any

from sqlalchemy import Column, DateTime, ForeignKey, String, Table
from sqlalchemy.orm import relationship

from sophia.model.base import Base


def str_uuid() -> str:
    """Creates a UUID string.

    Returns:
        A UUID.
    """
    return str(uuid.uuid4())


# Class cannot subclass "Base" (has type "Any")  [misc]
# https://docs.sqlalchemy.org/en/14/orm/extensions/mypy.html states that the 1.4
# approach will be replaced in 2.0 and should be considered legacy.
# Issue: Base is an unspecified, dynamically generated class from SQLAlchemy
class CollectionEndpoint(Base):  # type: ignore
    """A single collection endpoint for a source."""

    __tablename__ = "collection_endpoint"

    id = Column(String, default=str_uuid, primary_key=True)
    """UUID primary key."""

    created = Column(DateTime, default=datetime.datetime.utcnow)
    modified = Column(
        DateTime,
        default=datetime.datetime.utcnow,
        onupdate=datetime.datetime.utcnow,
        nullable=False,
    )

    url = Column(String, nullable=False)


collection_source_endpoints_table = Table(
    "collection_source_endpoints",
    Base.metadata,  # type: ignore
    Column(
        "endpoint_id", String, ForeignKey("collection_endpoint.id"), primary_key=True
    ),
    Column(
        "collection_source_id",
        String,
        ForeignKey("collection_source.id"),
        primary_key=True,
    ),
)
"""A table to establish a many-to-many relationship between endpoints and sources."""


class CollectionSource(Base):  # type: ignore
    """A collection source is an aggregate of sources and methods."""

    __tablename__ = "collection_source"

    id = Column(String, default=str_uuid, primary_key=True)
    """UUID primary key."""

    created = Column(DateTime, default=datetime.datetime.utcnow)
    modified = Column(
        DateTime,
        default=datetime.datetime.utcnow,
        onupdate=datetime.datetime.utcnow,
        nullable=False,
    )

    endpoints: Any = relationship(
        CollectionEndpoint, secondary=collection_source_endpoints_table
    )

    name = Column(String, nullable=False)
    description = Column(String)

#!/usr/bin/env python3
#
# © 2022 The Johns Hopkins University Applied Physics Laboratory LLC (JHU/APL).
# All Rights Reserved.  This material may be only be used, modified, or
# reproduced by or for the U.S.  Government pursuant to the license rights
# granted under the clauses at DFARS 252.227-7013/7014 or FAR 52.227-14. For any
# other permission, please contact the Office of Technology Transfer at JHU/APL:
# Telephone: 443-778-2792, Internet: www.jhuapl.edu/ott
#
# NO WARRANTY, NO LIABILITY. THIS MATERIAL IS PROVIDED "AS IS." JHU/APL MAKES NO
# REPRESENTATION OR WARRANTY WITH RESPECT TO THE PERFORMANCE OF THE MATERIALS,
# INCLUDING THEIR SAFETY, EFFECTIVENESS, OR COMMERCIAL VIABILITY, AND DISCLAIMS
# ALL WARRANTIES IN THE MATERIAL, WHETHER EXPRESS OR IMPLIED, INCLUDING (BUT NOT
# LIMITED TO) ANY AND ALL IMPLIED WARRANTIES OF PERFORMANCE, MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL
# PROPERTY OR OTHER THIRD PARTY RIGHTS. ANY USER OF THE MATERIAL ASSUMES THE
# ENTIRE RISK AND LIABILITY FOR USING THE MATERIAL. IN NO EVENT SHALL JHU/APL BE
# LIABLE TO ANY USER OF THE MATERIAL FOR ANY ACTUAL, INDIRECT, CONSEQUENTIAL,
# SPECIAL OR OTHER DAMAGES ARISING FROM THE USE OF, OR INABILITY TO USE, THE
# MATERIAL, INCLUDING, BUT NOT LIMITED TO, ANY DAMAGES FOR LOST PROFITS.
"""Proof-of-concept PDF scraper.

This scraper uses the tabula-py package to extract values from the Palau
Ministry of Health website.
"""

import contextlib
import io
import tempfile
from typing import Dict, Generator, List, Tuple, cast

import pandas as pd
import requests
from tabula.io import read_pdf

Coordinates = Tuple[float, float, float, float]
CoordinatesDict = Dict[str, Coordinates]


def get_value_by_coordinates(pdf_file: io.BytesIO, coordinates: Coordinates) -> str:
    """Gets a single value from a PDF file using the Tabula PDF reader.

    Args:
        pdf_file: Bytes stream of PDF content
        coordinates: Coordinates of a string to retrieve

    Returns:
        A string at a given location
    """
    pdf_file.seek(0)
    data_frames: List[pd.DataFrame] = cast(
        List[pd.DataFrame],
        read_pdf(
            pdf_file,
            multiple_tables=False,
            pages=1,
            stream=True,
            encoding="utf-8",
            area=coordinates,
            pandas_options={"header": None},
        ),
    )
    data_frame = data_frames[0]
    result: str = data_frame[0].iloc[0]
    return result


@contextlib.contextmanager
def download_pdf(url: str) -> Generator[io.BytesIO, None, None]:
    """Downloads the PDF and yields a temporary file.

    Args:
        url: URL to the PDF to download.

    Yields:
        Iterator: Stream of bytes in a temporary file
    """
    # Palau's website has an invalid certificate, but we still want the PDF.
    pdf_response = requests.get(url, verify=False)  # nosec B501  # noqa: S501
    with tempfile.NamedTemporaryFile("w+b") as named_temp_file:
        named_temp_file.write(pdf_response.content)
        yield cast(io.BytesIO, named_temp_file)


def parse_int(value: str) -> int:
    """Parses a string into an integer, removing punctuation.

    Args:
        value: An integer-like value in string form

    Returns:
        An integer representation from a string
    """
    return int(str(value).replace(",", ""))


def get_values_from_pdf_by_coordinates(
    url: str, coordinates_by_field: CoordinatesDict
) -> Dict[str, int]:
    """Collector that retrieves values from a PDF.

    Collector that retrieves values from a PDF, in which the values are
    referenced by location.

    Args:
        url: URL of the PDF coordinates: Dictiorary mapping fields to
            coordinates
        coordinates_by_field: Coordinates in dictionary form.

    Returns:
        A dictionary mapping fields to values
    """
    pdf_file: io.BytesIO
    with download_pdf(url) as pdf_file:
        values = {}
        for statistic, fields in coordinates_by_field.items():
            values[statistic] = parse_int(get_value_by_coordinates(pdf_file, fields))
    return values


PALAU_PDF_STATISTIC_COORDINATES = {
    "recovered": (287.4, 436.52, 364.67, 598.6),
    "confirmed": (387.72, 436.52, 465.15, 598.6),
    "deaths": (501.78, 54.5, 582.89, 216.53),
}
"""Coordinates of values in the Palau Ministry of Health PDF."""

PALAU_PDF_URL = "http://www.palauhealth.org/2019nCoV_SitRep/MOH-COVID-19%20Situation%20Report.pdf"  # noqa: B950
"""Example PDF URL."""

if __name__ == "__main__":
    values = get_values_from_pdf_by_coordinates(
        PALAU_PDF_URL, PALAU_PDF_STATISTIC_COORDINATES
    )
    for key, value in values.items():
        print(f"{key} = {value}")

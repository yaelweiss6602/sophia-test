#!/usr/bin/env python3
#
# © 2022 The Johns Hopkins University Applied Physics Laboratory LLC (JHU/APL).
# All Rights Reserved.  This material may be only be used, modified, or
# reproduced by or for the U.S.  Government pursuant to the license rights
# granted under the clauses at DFARS 252.227-7013/7014 or FAR 52.227-14. For any
# other permission, please contact the Office of Technology Transfer at JHU/APL:
# Telephone: 443-778-2792, Internet: www.jhuapl.edu/ott
#
# NO WARRANTY, NO LIABILITY. THIS MATERIAL IS PROVIDED "AS IS." JHU/APL MAKES NO
# REPRESENTATION OR WARRANTY WITH RESPECT TO THE PERFORMANCE OF THE MATERIALS,
# INCLUDING THEIR SAFETY, EFFECTIVENESS, OR COMMERCIAL VIABILITY, AND DISCLAIMS
# ALL WARRANTIES IN THE MATERIAL, WHETHER EXPRESS OR IMPLIED, INCLUDING (BUT NOT
# LIMITED TO) ANY AND ALL IMPLIED WARRANTIES OF PERFORMANCE, MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL
# PROPERTY OR OTHER THIRD PARTY RIGHTS. ANY USER OF THE MATERIAL ASSUMES THE
# ENTIRE RISK AND LIABILITY FOR USING THE MATERIAL. IN NO EVENT SHALL JHU/APL BE
# LIABLE TO ANY USER OF THE MATERIAL FOR ANY ACTUAL, INDIRECT, CONSEQUENTIAL,
# SPECIAL OR OTHER DAMAGES ARISING FROM THE USE OF, OR INABILITY TO USE, THE
# MATERIAL, INCLUDING, BUT NOT LIMITED TO, ANY DAMAGES FOR LOST PROFITS.

"""Sample PDF scraper that use the pdfreader package.

Sample PDF scraper that gets data from Oklahoma DOH using pdfreader and
requests.
"""

import re
from html.parser import HTMLParser
from io import BytesIO
from typing import Any, List, Optional, Tuple

import requests

# No stubs or types available
from pdfreader import SimplePDFViewer  # type: ignore

OKLAHOMA_ROOT_URL = "https://oklahoma.gov"
REPORTS_HOME_URL = f"{OKLAHOMA_ROOT_URL}/covid19/newsroom/weekly-epidemiology-and-surveillance-report.html"  # noqa: B950


class PdfUrlExtractor(HTMLParser):
    """Get the first <a> tag that contains a COVID-19 weekly press release."""

    def __init__(self) -> None:
        """Assigns an initial empty URL."""
        super().__init__()
        self.url: Optional[str] = None

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, Any]]) -> None:
        """Looks for weekly-epi-report reference tag.

        Args:
            tag: The tag to filter on, i.e., "a"q
            attrs: The dictionrary of tags.
        """
        if self.url is not None:
            return
        if tag != "a":
            return
        for name, value in attrs:
            if name == "href":
                if "weekly-epi-report" in value:
                    self.url = value
                    return


def read_pdf(url: str) -> int:
    """Reads a PDF, given a URL.

    Args:
        url: The URL of the PDF.

    Raises:
        RuntimeError: The deaths string could not be extracted.

    Returns:
        Number of deaths.
    """
    resp = requests.get(url)
    viewer = SimplePDFViewer(BytesIO(resp.content))

    viewer.navigate(1)
    viewer.render()
    m_strings = viewer.canvas.strings
    extracted_text = "".join(m_strings)

    # This regex might need to be updated if the table text changes
    # or if the number of deaths grows to 1M+
    deaths_match = re.search(r"Total Deaths (\d{2,3},\d{3})", extracted_text)
    if not deaths_match:
        raise RuntimeError(
            "Could not find data for total deaths.  Please verify the regex."
        )
    report_deaths = int(deaths_match.groups()[0].replace(",", ""))
    return report_deaths


def find_pdf() -> Optional[str]:
    """Find the weekly COVID report on the Oklahoma web site.

    Returns:
        None if unable to find a URL for a weekly report.
    """
    resp = requests.get(REPORTS_HOME_URL)
    finder = PdfUrlExtractor()
    finder.feed(resp.text)
    return finder.url


def run() -> None:
    """Entry point to the PDF scraper."""
    url = find_pdf()
    if url is None:
        raise RuntimeError("Could not find url of Oklahoma weekly report")
    if not "http" == url[0:4]:
        url = OKLAHOMA_ROOT_URL + url
    print(url)
    deaths = read_pdf(url)
    print(f"deaths: {deaths}")


if __name__ == "__main__":
    run()

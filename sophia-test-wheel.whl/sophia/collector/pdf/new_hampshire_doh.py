#!/usr/bin/env python3
#
# © 2022 The Johns Hopkins University Applied Physics Laboratory LLC (JHU/APL).
# All Rights Reserved.  This material may be only be used, modified, or
# reproduced by or for the U.S.  Government pursuant to the license rights
# granted under the clauses at DFARS 252.227-7013/7014 or FAR 52.227-14. For any
# other permission, please contact the Office of Technology Transfer at JHU/APL:
# Telephone: 443-778-2792, Internet: www.jhuapl.edu/ott
#
# NO WARRANTY, NO LIABILITY. THIS MATERIAL IS PROVIDED "AS IS." JHU/APL MAKES NO
# REPRESENTATION OR WARRANTY WITH RESPECT TO THE PERFORMANCE OF THE MATERIALS,
# INCLUDING THEIR SAFETY, EFFECTIVENESS, OR COMMERCIAL VIABILITY, AND DISCLAIMS
# ALL WARRANTIES IN THE MATERIAL, WHETHER EXPRESS OR IMPLIED, INCLUDING (BUT NOT
# LIMITED TO) ANY AND ALL IMPLIED WARRANTIES OF PERFORMANCE, MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT OF INTELLECTUAL
# PROPERTY OR OTHER THIRD PARTY RIGHTS. ANY USER OF THE MATERIAL ASSUMES THE
# ENTIRE RISK AND LIABILITY FOR USING THE MATERIAL. IN NO EVENT SHALL JHU/APL BE
# LIABLE TO ANY USER OF THE MATERIAL FOR ANY ACTUAL, INDIRECT, CONSEQUENTIAL,
# SPECIAL OR OTHER DAMAGES ARISING FROM THE USE OF, OR INABILITY TO USE, THE
# MATERIAL, INCLUDING, BUT NOT LIMITED TO, ANY DAMAGES FOR LOST PROFITS.
"""Sample PDF scraper that uses PyPDF23.

This scraper gets data from New Hampshire DOH using PyPDF2 and requests.
"""

import re
from html.parser import HTMLParser
from io import BytesIO
from typing import Any, List, Optional, Tuple, cast

import PyPDF2
import requests

NH_DOH_URL = "https://www.covid19.nh.gov"
UPDATE_URL = NH_DOH_URL + "/news/dhhs-updates"


class PdfUrlExtractor(HTMLParser):
    """Get the first <a> tag that contains a COVID-19 weekly press release."""

    def __init__(self) -> None:
        """Extends the standard HTML parser."""
        super().__init__()
        self.url: Optional[str] = None

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, Any]]) -> None:
        """Sets the internal URL if unset, is an "a" and href is found.

        Args:
            tag: The incoming tag to filter. Must be "a" to be used.
            attrs: The tags to scan.
        """
        if self.url is not None:
            return
        if tag != "a":
            return
        for name, value in attrs:
            if name == "href":
                if "press-release-nh-dhhs-weekly-covid-19-update-week" in value:
                    self.url = value
                    return


def read_pdf(url: str) -> Tuple[int, int]:
    """Read in the PDF and extract confirmed cases and deaths.

    Args:
        url: URL of PDF file.

    Returns:
        A tuple of cases and deaths.
    """
    resp = requests.get(url)
    pdf = PyPDF2.PdfFileReader(BytesIO(resp.content))
    pdf_str_list = []
    for i in range(pdf.getNumPages()):
        pdf_str_list.append("".join(pdf.getPage(i).extractText().split()))

    for pdf_str in pdf_str_list:
        if "NHPersonswithCOVID-19" in pdf_str or "NHTotalCaseCount" in pdf_str:
            break

    # Remove all whitespace because the PDF parsing sometimes puts
    # whitespace in strange places.

    cases_str = cast(
        re.Match[str],
        re.search(
            r"NH(TotalCaseCount|PersonswithCOVID-19)(?P<cases>\d+[,]?\d+)New", pdf_str
        ),
    ).group("cases")
    cases = int(cases_str.replace(",", ""))

    deaths_str = cast(
        re.Match[str],
        re.search(r"DeathsAttributedtoCOVID-19(?P<deaths>\d+[,]?\d+)", pdf_str),
    ).group("deaths")
    deaths = int(deaths_str.replace(",", ""))

    return cases, deaths


def find_pdf() -> Optional[str]:
    """Find the weekly COVID report on the New Hampshire web site.

    Returns:
        The weekly report URL.
    """
    resp = requests.get(UPDATE_URL)
    finder = PdfUrlExtractor()
    finder.feed(resp.text)
    return finder.url


def run() -> None:
    """Entry point to the PDF scraper."""
    url = find_pdf()
    if url is None:
        raise RuntimeError("Could not find url of New Hampshire weekly report")
    if not "http" == url[0:4]:
        url = NH_DOH_URL + url
    print(url)
    cases, deaths = read_pdf(url)
    print(f"confirmed cases: {cases}, deaths: {deaths}")


if __name__ == "__main__":
    run()

"""Raw source collectors."""

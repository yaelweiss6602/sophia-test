from typing import Any

from sophia.pipeline.data_entities import ValidationResult


def csv_syntax_validator(fp: str, syntax: Any) -> ValidationResult:
    return ValidationResult(0, "Stub function that does not checks returns fine")

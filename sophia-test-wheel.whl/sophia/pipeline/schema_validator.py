import warnings

from pyspark.sql import Column, DataFrame
from pyspark.sql.functions import col, udf, when

from sophia.pipeline.data_entities import ColumnSchema, TableSchema, ValidationResult

NUMBER_TYPES: list[str] = ["int", "long", "double", "float"]


def validate_number(df: DataFrame, column_schema: ColumnSchema) -> None:

    if column_schema.min is not None:
        if df.where(df[column_schema.title] < column_schema.min).count() != 0:
            raise ValueError("Column does not conform to schema requirement: min")

    if column_schema.max is not None:
        if df.where(df[column_schema.title] > column_schema.max).count() != 0:
            raise ValueError("Column does not conform to schema requirement: max")

    if column_schema.factor is not None:
        if df.where((df[column_schema.title] % column_schema.factor) != 0).count() != 0:
            raise ValueError("Column does not conform to schema requirement: max")



def validate_string(df: DataFrame, column_schema: ColumnSchema) -> None:
    column = col(column_schema.title)

    if column_schema.regex:
        tdf = df.withColumn("rmatch", column.rlike(column_schema.regex))
        if tdf.where(tdf.rmatch == False).count() > 0:
            raise ValueError("Column does not conform to schema requirement: regex")


def validate_schema(df: DataFrame, schema: TableSchema) -> ValidationResult:

    for column in schema.columns:
        if column.title not in df.schema.names:
            print(column.title)
            print(list(df.schema.names))

            return ValidationResult(code=1, message=f"Expected Column '{column.title}' was not present in data")

    schema_col_names = [col.title for col in schema.columns]

    for column_name in df.schema.names:
        if column_name not in schema_col_names:
            warnings.warn(f'WARNING: Column "{column}" found in data, but is not described in schema.')

    schemas = {c.title : c for c in schema.columns}
    for field, column_schema in ((f, schemas[f.name]) for f in df.schema.fields):
        expected_type = column_schema.data_type
        actual_type = field.dataType.simpleString()

        if expected_type != actual_type:
            if expected_type in NUMBER_TYPES and actual_type in NUMBER_TYPES:
                warnings.warn(f"WARNING: Column: '{field.name}' is not the same datatype, but maybe compatible. Expected '{expected_type}' got '{actual_type}'. Will attempt to continue")
            else:
                raise TypeError(f"Column: '{field.name}' was expected to be '{expected_type}', but was found to be '{actual_type}'.")

        if actual_type == "string":
            validate_string(df, column_schema)
        elif actual_type in NUMBER_TYPES:
            validate_number(df, column_schema)
        else:
            raise NotImplementedError("Unimplemented type detected.")

    return ValidationResult(code=0, message="Success")

from typing import NamedTuple, Optional, Union

from pydantic import BaseModel


class ValidationResult(NamedTuple):
    code: int
    message: str


class CSVLoadParameters(BaseModel):
    seperator: str = ","
    encoding: str = "UTF-8"
    skip_lines: int = 0
    header: bool = False


class ExcelLoadParameters(BaseModel):
    cellAddress: str = "A1"
    headerRowCount: int = 0


class JSONLoadParameters(BaseModel):
    data_root: list[str]


class ColumnSchema(BaseModel):
    title: str
    data_type: str
    min: Optional[Union[int, float]]
    max: Optional[Union[int, float]]
    factor: Optional[Union[int, float]]
    regex: Optional[str]


class TableSchema(BaseModel):
    columns: list[ColumnSchema]


class ColumnTranslation(BaseModel):
    name: str
    args: list[str]
    functor: Optional[str]  # TODO Change to an enum of available transformers.


class DataFrameTranslation(BaseModel):
    column_translators: list[ColumnTranslation]

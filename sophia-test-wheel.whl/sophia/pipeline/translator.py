from pyspark.sql import DataFrame
from pyspark.sql.functions import col

from sophia.pipeline.column_generators import functors
from sophia.pipeline.data_entities import DataFrameTranslation


def apply_column_translations(df: DataFrame, translation: DataFrameTranslation) -> DataFrame:

    for t in translation.column_translators:
        df = df.withColumn(f"$$${t.name}", functors[t.functor](*[col(x) for x in t.args]))

    # filter and reorder the dataframe to only the desired columns
    df = df.select([f"$$${t.name}" for t in translation.column_translators])
    return df.toDF(*[t.name for t in translation.column_translators])

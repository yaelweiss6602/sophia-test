from pyspark.sql import DataFrame, SparkSession

from sophia.pipeline.data_entities import (
    CSVLoadParameters,
    ExcelLoadParameters,
    JSONLoadParameters,
)


def load_csv(spark: SparkSession, url: str, loading_parameters: CSVLoadParameters) -> DataFrame:
    """
    Takes a url of a json file with the top level object being an array of objects
    where each object is a row in the data. As uch each object in the array should
    have the same set of keys.
    """
    # TODO: add support for skip lines on load

    return (
        spark.read.format("CSV")
        .option("sep", loading_parameters.seperator)
        .option("encoding", loading_parameters.encoding)
        .option("header", loading_parameters.header)
        .option("inferSchema", "true")
        .load(url)
    )


def load_excel(spark: SparkSession, url: str, loading_parameters: ExcelLoadParameters) -> DataFrame:
    """
    Takes a url of a json file with the top level object being an array of objects
    where each object is a row in the data. As uch each object in the array should
    have the same set of keys.
    """

    return (
        spark.read.format("excel")
        .option("cellAddress", loading_parameters.cellAddress)
        .option("headerRowCount", loading_parameters.headerRowCount)
        .load(url)
    )


def loadjson(spark: SparkSession, url: str, loading_parameters: JSONLoadParameters) -> DataFrame:
    """
    Takes a url of a json file with the top level object being an array of objects
    where each object is a row in the data. As uch each object in the array should
    have the same set of keys.
    """
    # TODO: add support for extracting the array of rows from a more complex json file.
    return spark.read.json(url, multiLine=True)

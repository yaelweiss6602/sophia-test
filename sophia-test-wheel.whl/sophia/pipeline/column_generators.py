from typing import Callable, Optional

from pyspark.sql import Column
from pyspark.sql.functions import lower, udf, upper
from pyspark.sql.types import DoubleType, IntegerType


def str_to_int(col: Column) -> Column:
    return col.cast(IntegerType())


def str_to_double(col: Column) -> Column:
    return col.cast(DoubleType())


@udf(returnType=IntegerType())
def years_to_days(x: int) -> int:
    return x * 365


def nop(col: Column) -> Column:
    return col


functors: dict[Optional[str], Callable[[Column], Column]] = {
    "str_to_int": str_to_int,
    "str_to_double": str_to_double,
    "lower": lower,
    "upper": upper,
    "years_to_days": years_to_days,
    None: nop
}

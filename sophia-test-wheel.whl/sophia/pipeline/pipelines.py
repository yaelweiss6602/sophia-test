from typing import Any

from pyspark.sql import DataFrame, SparkSession

from sophia.pipeline.data_entities import (
    CSVLoadParameters,
    DataFrameTranslation,
    TableSchema,
)
from sophia.pipeline.loaders import load_csv
from sophia.pipeline.schema_validator import validate_schema
from sophia.pipeline.syntax_validators import csv_syntax_validator
from sophia.pipeline.translator import apply_column_translations


def schema_validate_and_translate(df: DataFrame, schema: TableSchema, translators: DataFrameTranslation) -> DataFrame:

    print("******************************************************************7")
    schema_validation = validate_schema(df, schema=schema)

    if schema_validation.code != 0:
        raise ValueError(f"Parsed dataframe does not match expected schema, with message: {schema_validation.message}")
    print("******************************************************************7.9")
    print(df)
    df.show()

    print("******************************************************************8")
    return apply_column_translations(df, translators)


def csv_pipeline(spark: SparkSession, file_pointer: str, syntax: Any, loading_parameters: CSVLoadParameters, schema: TableSchema, translation: DataFrameTranslation) -> DataFrame:

    syntax_validation = csv_syntax_validator(file_pointer, syntax=syntax)

    if syntax_validation.code != 0:
        raise ValueError("Parsed file does not match expected syntax.")

    df = load_csv(spark, file_pointer, loading_parameters=loading_parameters)
    print(df)

    return schema_validate_and_translate(df, schema, translation)
